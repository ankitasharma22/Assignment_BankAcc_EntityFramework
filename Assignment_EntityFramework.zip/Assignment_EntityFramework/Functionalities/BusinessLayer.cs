﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DBConnection;
namespace Functionalities
{
    public class BusinessLayer
    {
       
        public void AddClient(DBConnection.BankDetail bankDetail)
        {
            DAL db = new DAL();
            db.CreateCustomer(bankDetail);
            Console.WriteLine("----------Account has been added successfully! Happy banking :)------------");
        }

        public void BL_Search(int ID)
        {
            DAL db = new DAL();
            db.SearchById(ID);
        }

        public void BL_Display()
        {
            DAL db = new DAL();
            db.DisplayAllClients();
        }

        public void BL_Deposit(int AccountNumber, int Money)
        {
            DAL db = new DAL();
            db.DepositMoney(AccountNumber, Money);
        }
        public void BL_Withdraw(int AccountNumber, int Money)
        {
            DAL db = new DAL();
            db.WithdrawMoney(AccountNumber, Money);
        }
        public void BL_Interest(int AccountNumber)
        {
            DAL db = new DAL();
            db.CalculateInterest(AccountNumber);
        }
    }
}
