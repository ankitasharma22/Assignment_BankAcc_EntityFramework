﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using Functionalities;
using DBConnection;
namespace Assignment_EntityFramework
{
  
    class BankEntities : DbContext
    {
        static void Main(string[] args)
        {
            Console.WriteLine("******* WELCOME TO TAVISCA SOLUTIONS BANK ********");
            Console.WriteLine();
            int userChoice = 0;
            bool flag = false;
            BusinessLayer b1 = new BusinessLayer();
            do
            {
                Console.WriteLine(" --- CHOOSE YOUR ACTION AMONG THE FOLLOWING ---");
                Console.WriteLine("1. Create Bank Account ");
                Console.WriteLine("2. Search Account By Account Number ");
                Console.WriteLine("3. See all customer details ");
                Console.WriteLine("4. Deposit Money ");
                Console.WriteLine("5. Withdraw Money");
                Console.WriteLine("6. Calculate Interest ");
                Console.WriteLine("7. Exit ");
                userChoice = Convert.ToInt32(Console.ReadLine());
                switch (userChoice)
                {
                    case 1:
                        DBConnection.BankDetail newClient = new DBConnection.BankDetail();
                        Console.WriteLine("_______HELLO NEW USER!________");
                        Console.WriteLine("Enter Account Holder name ");
                        newClient.AccountHolder = Console.ReadLine();
                        Console.WriteLine("Enter Amount ");
                        newClient.Amount = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter Account Type ");
                        Console.WriteLine("*****Valid Account Types*****");
                        Console.WriteLine("Saving / Current / DMAT ");
                        do
                        {
                            newClient.AccountType = Console.ReadLine();
                            if (!(newClient.AccountType == "Saving" || newClient.AccountType == "Current" || newClient.AccountType == "DMAT"))
                            {
                                Console.WriteLine("Wrong entry. Please try again. ");
                                flag = true;
                            }
                            else
                                flag = false;
                        } while (flag);

                        b1.AddClient(newClient);

                        break;
                    case 2:
                        BankDetail newClient2 = new BankDetail();
                        Console.WriteLine("_______SEARCH BY ACCOUNT NUMBER________");
                        Console.WriteLine("Enter Account Number ");
                        int AccNumber = Convert.ToInt32(Console.ReadLine());
                        b1.BL_Search(AccNumber);
                        break;

                    case 3:
                        b1.BL_Display();
                        break;

                    case 4:
                       
                        Console.WriteLine("_______DEPOSIT MONEY________");
                        Console.WriteLine("Enter Account Number ");
                        int accNumber = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Deposit Money");
                        int depositMoney = Convert.ToInt32(Console.ReadLine());
                        b1.BL_Deposit(accNumber, depositMoney);
                        break;

                    case 5:
                        Console.WriteLine("Enter Account Number ");
                        int acc = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Withdraw Money");
                        int withdrawMoney = Convert.ToInt32(Console.ReadLine());
                        b1.BL_Withdraw(acc, withdrawMoney);                        
                        break;

                    case 6:
                        Console.WriteLine("____CALCULATE INTEREST____");
                        Console.WriteLine("Enter Account Number ");
                        int accNumber1 = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Interest is calculated as per account type...");
                        Console.WriteLine("Saving Account - 40%, Current Account - 10%");
                        b1.BL_Interest(accNumber1);
                        break;

                    default:
                        Console.WriteLine(" You entered a wrong choice! Please try again. ");
                        break;

                }
            } while (userChoice != 7);
        }
    }
    
}
