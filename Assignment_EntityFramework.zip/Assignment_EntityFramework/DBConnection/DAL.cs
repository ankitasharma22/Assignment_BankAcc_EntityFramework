﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBConnection
{
    public class DAL
    {
        public void CreateCustomer(BankDetail newClient)
        {
            BankAccountEntities entity_Case1 = new BankAccountEntities();
            entity_Case1.BankDetails.Add(newClient);
            entity_Case1.SaveChanges();
        }
        public void SearchById(int searchAcc)
        {
            BankAccountEntities entity_Case2 = new BankAccountEntities();
            List<BankDetail> Accountlist = entity_Case2.BankDetails.ToList();
            for (int i = 0; i < Accountlist.Count; i++)
            {
                if (Accountlist[i].AccountNumber == searchAcc)
                {
                    Console.WriteLine("---Account Number--- {0}", Accountlist[i].AccountNumber);
                    Console.WriteLine("---Account Holder--- {0}", Accountlist[i].AccountHolder);
                    Console.WriteLine("---Amount        --- {0}", Accountlist[i].Amount);
                    Console.WriteLine("---Account Type  --- {0}", Accountlist[i].AccountType);
                }
            }
            Console.WriteLine("");
        }

        public void DisplayAllClients()
        {
            BankAccountEntities entity_Case7 = new BankAccountEntities();
            List<BankDetail> list = entity_Case7.BankDetails.ToList();
            for (int i = 0; i < list.Count; i++)
            {
                Console.WriteLine("---Account Number--- {0}", list[i].AccountNumber);
                Console.WriteLine("---Account Holder--- {0}", list[i].AccountHolder);
                Console.WriteLine("---Amount        --- {0}", list[i].Amount);
                Console.WriteLine("---Account Type  --- {0}", list[i].AccountType);
            }
            Console.WriteLine("");
        }

        public void DepositMoney(int AccNo, int extraMoney)
        {
            BankDetail newClient3 = new BankDetail();
            BankAccountEntities entity_Case3 = new BankAccountEntities();
            int initialMoney = entity_Case3.BankDetails.Find(newClient3.AccountNumber).Amount;
            entity_Case3.BankDetails.Find(newClient3.AccountNumber).Amount = initialMoney + extraMoney;
            entity_Case3.SaveChanges();
            Console.WriteLine("-----Money updated successfully-----");
        }

        public void WithdrawMoney(int AccNo, int extraMoney)
        {
            BankDetail newClient4 = new BankDetail();
            BankAccountEntities entity_Case4 = new BankAccountEntities();
            Console.WriteLine("_______WITHDRAW MONEY________");
            int initialMoney1 = entity_Case4.BankDetails.Find(newClient4.AccountNumber).Amount;
            int updatedAmount = initialMoney1 - extraMoney;
            string accountType = entity_Case4.BankDetails.Find(newClient4.AccountNumber).AccountType;

            if (accountType == "Saving" && updatedAmount < 1000)
                Console.WriteLine(" Insufficient Balance");
            else if (accountType == "Current" && updatedAmount < 0)
                Console.WriteLine("Insufficient Balance ");
            else if (accountType == "DMAT" && updatedAmount < -10000)
                Console.WriteLine("Insufficient Balance ");
            else
            {
                entity_Case4.BankDetails.Find(newClient4.AccountNumber).Amount = updatedAmount;
                entity_Case4.SaveChanges();
                Console.WriteLine("-----Money updated successfully-----");
            }
        }

        public void CalculateInterest(int AccNo)
        {
            BankDetail newClient5 = new BankDetail();
            BankAccountEntities entity_Case5 = new BankAccountEntities();
            double interest = 0;
            string accountType1 = entity_Case5.BankDetails.Find(newClient5.AccountNumber).AccountType;
            if (accountType1 == "Saving")
            {
                interest = entity_Case5.BankDetails.Find(newClient5.AccountNumber).Amount * 0.04;
                Console.WriteLine(" Interest Calculated on saving account is {0}", interest);
            }
            else if (accountType1 == "Current")
            {
                interest = entity_Case5.BankDetails.Find(newClient5.AccountNumber).Amount * 0.01;
                Console.WriteLine(" Interest Calculated is current is {0}", interest);
            }
            else
                Console.WriteLine(" No interest is calculated on DMAT Account ");
        }
    }
}
